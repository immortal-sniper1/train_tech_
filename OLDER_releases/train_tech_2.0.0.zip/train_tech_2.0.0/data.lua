
require('prototypes.technology')
data.raw["cargo-wagon"]["cargo-wagon"].max_speed = 25
data.raw["artillery-wagon"]["artillery-wagon"].max_speed = 25
data.raw["fluid-wagon"]["fluid-wagon"].max_speed = 25